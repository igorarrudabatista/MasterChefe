<div class="tab-pane fade" id="list-tramitar" role="tabpanel" aria-labelledby="list-projeto-tramitar">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title"> <b> <big> 7. </b> </big>
                Finalizar </h5>
            
            <button type="submit" class="btn btn-success"> FINALIZAR E TRAMITAR </button>
            
            </select>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\00054957176\PROJETOS\TR\resources\views/trdigital/criar/questoes/tramitar.blade.php ENDPATH**/ ?>