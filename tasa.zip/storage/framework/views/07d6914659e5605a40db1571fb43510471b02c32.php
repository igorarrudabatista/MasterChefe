
<?php $__env->startSection('content'); ?>
<?php 
$processoCount = session()->get('processoCount'); 
$processoCount_corrigir = session()->get('processoCount_corrigir'); 
$processoCount_finalizado = session()->get('processoCount_finalizado'); 
$processoCount_aguardando = session()->get('processoCount_aguardando'); 
$processoCount_tramitada = session()->get('processoCount_tramitada'); 
$processoCount_nao_finalizada = session()->get('processoCount_nao_finalizada'); 
?>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
<!-- Adicione esses links no cabeçalho do seu HTML -->
<!-- Adicione esses links no cabeçalho do seu HTML -->

    <main id="main" class="main">

    
    

        <div class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="col-md-12 ml-auto mr-auto">
                        <div class="card card-upgrade">
                            <div class="card-header">


                                <!--//row-->

                                <section id="multiple-column-form">
                                    <div class="row match-height">
                                        <div class="col-12">

                                            <br>



                                            <div class="text-center mb-5">
                                                <img src="<?php echo e(asset('/images/createform.png')); ?>" height="88"
                                                    class='mb-4'>
                                                <h3>TR DIGITAL - Criar Nova TR</h3>
                                                <p> Valide os itens dos formulários</p>

                                                <div class="row">

                                                <div class="col-lg-4">
                                                    <?php echo Form::open(['route' => 'trdigital.store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>


                                                    <?php if(auth()->check()): ?>
                                                        <input type="hidden" name="user_id"
                                                            value="<?php echo e(auth()->user()->id); ?>">
                                                    <?php endif; ?>

                                                    <div class="row">
                                                      <div class="col-10">
                                                          <div class="list-group" id="list-tab" role="tablist">
                                                              <a class="list-group-item list-group-item-action active"
                                                                  id="list-home-list" data-bs-toggle="list" href="#list-home"
                                                                  role="tab" aria-controls="list-home"><big><b> Selecione o Orgão Concedente </b></big>
                                                                  </a>

                                                          </div></div></div>
                                       <!-- Seu código HTML do select -->
                                       <div class="row">
                                        <div class="col-lg-10">
                                            <select name="Orgao_Concedente" id="Orgao_Concedente" class="form-control custom-select" required>
                                                <option value="" disabled selected> 
                                                   Selecione o Orgão Concedente</option>
                                                <?php $__currentLoopData = $orgaos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orgao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($orgao->id); ?>">
                                                        <img src="<?php echo e(asset('images/brasao_mt.png')); ?>" width="20px"> <?php echo e($orgao->Sigla); ?> - <?php echo e($orgao->Nome); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                    </div>
                                    


                                                    </div>

                               
                                                    


                                                </div>
                                            </div>

                                        </div>

                                        <div class="row">
                                            <div class="col-4">
                                                <div class="list-group" id="list-tab" role="tablist">
                                                    <a class="list-group-item list-group-item-action active"
                                                        id="list-home-list" data-bs-toggle="list" href="#list-home"
                                                        role="tab" aria-controls="list-home"><big><b> 1. </b></big>
                                                        Ofícios</a>
                                                    <a class="list-group-item list-group-item-action" id="list-profile-list"
                                                        data-bs-toggle="list" href="#list-profile" role="tab"
                                                        aria-controls="list-profile"><big><b> 2. </b> </big>
                                                        Identificação do Responsável
                                                        pela Instituição. </b></a>
                                                    <a class="list-group-item list-group-item-action"
                                                        id="list-messages-list" data-bs-toggle="list" href="#list-messages"
                                                        role="tab" aria-controls="list-messages"><b> 3.</b>
                                                        </big>Identificação da
                                                        Instituição
                                                        Proponente </b> </a>
                                                    <a class="list-group-item list-group-item-action"
                                                        id="list-settings-list" data-bs-toggle="list" href="#list-settings"
                                                        role="tab" aria-controls="list-settings"><big><b> 4. </b> </big>
                                                        Identificação do
                                                        Responsável pelo Projeto </b> </a>
                                                    <a class="list-group-item list-group-item-action" id="list-atas-list"
                                                        data-bs-toggle="list" href="#list-atas" role="tab"
                                                        aria-controls="list-atas"><big> <b> 5. </b> </big></b> Atas,
                                                        Certidões,
                                                        Comprovantes e Declarações </a>
                                                    <a class="list-group-item list-group-item-action" id="list-projeto-list"
                                                        data-bs-toggle="list" href="#list-projeto" role="tab"
                                                        aria-controls="list-projeto"> <b> <big> 6. </big> </b> Identificação
                                                        do
                                                        Projeto </a>

                                                    <a class="list-group-item list-group-item-action"
                                                        id="list-projeto-tramitar" data-bs-toggle="list"
                                                        href="#list-tramitar" role="tab" aria-controls="list-tramitar">
                                                        <b> <big> 7. </big> </b> Finalizar e Enviar</a>

                                                </div>
                                            </div>

                                            <div class="col-8">
                                                <div class="tab-content" id="nav-tabContent">
                                                    <?php echo Form::open(['route' => 'trdigital.store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>


                                                    <?php echo $__env->make('trdigital.criar.questoes.1oficios', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <?php echo $__env->make('trdigital.criar.questoes.2resp_instituicao', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <?php echo $__env->make('trdigital.criar.questoes.3instituicao', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <?php echo $__env->make('trdigital.criar.questoes.4resp_projeto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <?php echo $__env->make('trdigital.criar.questoes.5doc_anexos2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <?php echo $__env->make('trdigital.criar.questoes.6projeto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <?php echo $__env->make('trdigital.criar.questoes.tramitar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                                                </div>
                                            </div>
                                        </div>



                                    </div>
                            </div>
                            </section>
    </main>
    <script>
      $(document).ready(function() {
          // Função para adicionar a imagem ao lado de cada opção do select
          function addImageToSelectOption() {
              var select = $('#Orgao_Concedente'); // Seletor do seu select
              select.find('option').each(function() {
                  var option = $(this);
                  var imageSrc = '<?php echo e(asset('images/brasao_mt.png')); ?>'; // Substitua pelo caminho correto da imagem
                  var imgElement = $('<img>').attr('src', imageSrc).css({
                      width: '20px', // Defina o tamanho da imagem aqui
                      marginRight: '5px' // Defina a margem direita para ajustar o espaçamento
                  });
                  option.prepend(imgElement);
              });
          }
  
          // Chame a função para adicionar a imagem ao carregar a página
          addImageToSelectOption();
      });
  </script>
    
    <!-- Adicione esses links no cabeçalho do seu HTML -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-beta.1/css/select2.min.css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-beta.1/js/select2.min.js"></script>


    <script src='https://cdnjs.cloudflare.com/ajax/libs/vue/2.4.4/vue.js'></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="<?php echo e(asset('js/step-by-step/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.novabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\00054957176\PROJETOS\TR\resources\views/trdigital/create.blade.php ENDPATH**/ ?>