
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

  
    <div class="pagetitle">
        <h1>Perfil do sistema</h1>
        <nav>
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Início</a></li>
            <li class="breadcrumb-item active">Perfil do sistema</li>
          </ol>
        </nav>
      </div><!-- End Page Title -->

    <section class="section">
        <div class="card">
            <div class="card-header">
            </div>
            <div class="card-body">
           <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
                
                <table class='table datatable' >
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Ações</th>
                          
                        </tr>
                    </thead>
                    
                    <tbody>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
               
                           <td><?php echo e($role->name); ?></td>
                          <td>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                <a class="btn btn-primary" href="<?php echo e(route('roles.edit',$role->id)); ?>">Editar</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
                <?php echo Form::open(['method' => 'DELETE','route' => ['roles.destroy', $role->id],'style'=>'display:inline']); ?>

                    <?php echo Form::submit('Deletar', ['class' => 'btn btn-danger']); ?>

                <?php echo Form::close(); ?>

            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
                
            </div>
        </div>
        
    </section>
</div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base.novabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\00054957176\PROJETOS\TR\resources\views/roles/index.blade.php ENDPATH**/ ?>