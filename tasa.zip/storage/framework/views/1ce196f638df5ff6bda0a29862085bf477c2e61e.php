
<?php echo Form::open(['route' => 'trdigital.store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

 
 <div class="tab-pane fade show active" id="list-home" role="tabpanel"
 aria-labelledby="list-home-list">

<div class="col-lg-12">

    <div class="card">
        <div class="card-body">
            <h5 class="card-title"> <big><b> 1. </b> </big> Ofício de encaminhamento com o
                <b>número da nova proposta </b></h5>

            <div class="row mb-3">

        

                <div class="col-sm-10">
                  
                  
                  <?php echo Form::file('Comp_Oficio', ['class' => 'form-control']); ?>

              </div>      
                
                </div>
                
                <button type="submit"
                class="btn btn-primary btn-sm">Salvar</button>
              </div>
            <br>
          </div>

    </div>
<div class="col-lg-12">

    <div class="card">
        <div class="card-body">
            <h5 class="card-title"> <big> <b> 2. </b> </big> Ofício com a destinação da emenda
                emitido e <b> assinado pelo Parlamentar</b></h5>

            <div class="row mb-3">

                <div class="col-sm-10">
                  <?php echo Form::file('Comp_Assinado', ['class' => 'form-control']); ?>


                </div>
            </div>


            <button type="submit"
            class="btn btn-primary btn-sm">Salvar</button>


        </div>
    </div>
    </div>
    </div>

<?php /**PATH C:\Users\00054957176\PROJETOS\TR\resources\views/trdigital/criar/questoes/1oficios.blade.php ENDPATH**/ ?>