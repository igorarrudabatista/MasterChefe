
<?php $__env->startSection('content'); ?>
<?php 
$processoCount = session()->get('processoCount'); 
$processoCount_corrigir = session()->get('processoCount_corrigir'); 
$processoCount_finalizado = session()->get('processoCount_finalizado'); 
$processoCount_aguardando = session()->get('processoCount_aguardando'); 
$processoCount_tramitada = session()->get('processoCount_tramitada'); 
$processoCount_nao_finalizada = session()->get('processoCount_nao_finalizada'); 
?>
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Dashboard</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Início</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row">

                <!-- Left side columns -->
                <div class="col-lg-12">
                    <div class="row">

                        <!-- Sales Card -->
                        <div class="col-xxl-3 col-md-3">
                            <div class="card info-card sales-card">



                                <div class="card-body">
                                    <h5 class="card-title">Inscrições <span></span></h5>

                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-file-text"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6> </h6>
                                            <span class="text-success small pt-1 fw-bold">Recebidas</span>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div><!-- End Sales Card -->

                        <!-- Revenue Card -->
                        <div class="col-xxl-3 col-md-3">
                            <div class="card info-card revenue-card">



                                <div class="card-body">
                                    <h5 class="card-title">Ingredientes <span></span></h5>

                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-basket"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6></h6>
                                            <span class="text-success small pt-1 fw-bold">Cadastradas</span>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div><!-- End Revenue Card -->

                        <!-- Customers Card -->
                        <div class="col-xxl-3 col-xl-3">

                            <div class="card info-card customers-card">


                                <div class="card-body">
                                    <h5 class="card-title">Escolas <span></span></h5>

                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bx bxs-school"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6> </h6>
                                            <span class="text-danger small pt-1 fw-bold">Cadastradas</span>

                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div><!-- End Customers Card -->
                        <div class="col-xxl-3 col-xl-3">

                            <div class="card info-card customers-card">


                                <div class="card-body">
                                    <h5 class="card-title">DRES <span></span></h5>

                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-people"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6></h6>
                                            <span class="text-danger small pt-1 fw-bold">Cadastradas</span>

                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div><!-- End Customers Card -->

                        

                        <div class="col-xxl-4 col-xl-4">

                          <div class="card info-card customers-card">


                              <div class="card-body">
                                  <h5 class="card-title"> Total de Votos <span></span></h5>

                                  <div class="d-flex align-items-center">
                                      <div
                                          class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                          <i class="bi bi-hand-thumbs-up"> </i>

                                      </div>

                         

                                      <div class="ps-3">
                                        <h6></h6>
                                        <span class="text-success small pt-1 fw-bold">Contabilizados</span>

                                    </div>
                                  </div>

                              </div>
                          </div>

                      </div><!-- End Customers Card -->

                      <?php if(Auth::check() && Auth::user()->hasRole('Admin')): ?>

                        <div class="col-xxl-4 col-xl-4">

                          <div class="card info-card customers-card">


                              <div class="card-body">
                                  <h5 class="card-title"> N° da Inscrição Vencedora <span></span></h5>

                                  <div class="d-flex align-items-center">
                                      <div
                                          class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                          <i class="bx bxs-trophy"> </i>

                                      </div>
                                      <div class="ps-3">
                                        
                                    <hr>
                                    <span class="text-success small pt-1 fw-bold">
                                        <h6>Votos:<span>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            </div>
                            
                        </div><!-- End Customers Card -->
                        <?php endif; ?>

                        <!-- Reports -->
                        <!-- End Reports -->

                        <!-- Recent Sales -->
                        <?php if(Auth::check() && Auth::user()->hasRole('seduc')): ?>

                        <div class="col-12">
                            <div class="card recent-sales overflow-auto">


                                <div class="card-body ">
                                    <h5 class="card-title">Lista de Votos<span></span></h5>

                                    <table class="table table-borderless datatable">
                                        <thead>
                                            <tr>
                                                <th scope="col">Id</th>
                                                <th scope="col">Nome</th>
                                                <th scope="col">DRE</th>
                                                <th scope="col">Escola</th>
                                                <th scope="col">Votos</th>
                                            </tr>
                                        </thead>


                                        <tbody>
                                            <?php $__currentLoopData = $recibos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recibo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>

                                                    <th scope="row"><a href="<?php echo e(asset('/inscricao/'.$recibo->id)); ?>"><?php echo e($recibo->id); ?></a></th>
                                                    <td><?php echo e($recibo->Nome); ?></td>
                                                    <td><a href="<?php echo e(asset('/inscricao/'.$recibo->id)); ?>" class="text-primary"><?php echo e($recibo->dre->Nome); ?></a>
                                                    </td>
                                                    <td><a href="<?php echo e(asset('/inscricao/'.$recibo->id)); ?>"
                                                            class="text-primary"><?php echo e($recibo->escola->EscolaNome); ?></a></td>

                                                    <td> <button type="button" class="btn btn-success mb-2">
                                                            <?php echo e($recibo->likes->count()); ?>

                                                        </button> </td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>

                                </div>

                            </div>
                        </div><!-- End Recent Sales -->
                        <?php endif; ?>


                    </div>
                </div><!-- End Left side columns -->

                <!-- Right side columns -->


                <!-- News & Updates Traffic -->
                
                <!-- End News & Updates -->

            </div><!-- End Right side columns -->

            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.novabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\00054957176\PROJETOS\TR\resources\views/painel/painel-dashboard.blade.php ENDPATH**/ ?>