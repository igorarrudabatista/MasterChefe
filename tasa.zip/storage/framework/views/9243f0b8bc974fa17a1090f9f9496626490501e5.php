
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">



        <div class="pagetitle">
            <h1>CIDADES</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Início</a></li>
                    <li class="breadcrumb-item active">Painel Gerencial</li>
                    <li class="breadcrumb-item active">Cidades</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->


        <a class="btn btn-primary" href="<?php echo e(route('cidade.create')); ?>"> Cadastrar</a>


        <section class="section">
            <div class="card">
                <div class="card-header">
                </div>
                <div class="card">

                    <div class="card-body">
                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e($message); ?></p>
                            </div>
                        <?php elseif($message = Session::get('edit')): ?>
                            <div class="alert alert-warning">
                                <p><?php echo e($message); ?></p>
                            </div>
                        <?php elseif($message = Session::get('delete')): ?>
                            <div class="alert alert-danger">
                                <p><?php echo e($message); ?></p>
                            </div>
                    </div>
                </div>
                <?php endif; ?>

                <table class='table datatable' id="table1">
                    <thead>

                        <tr>
                            <th>Nome</th>
                            <th>Ações</th>

                        </tr>
                    </thead>
                    <?php $__currentLoopData = $cidade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cidades): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($cidades->Nome); ?></td>

                        <td> <a class="btn btn-warning" href="<?php echo e(route('cidade.edit', $cidades->id)); ?>">Editar</a>
                        
                        </td>



                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

            </div>
            </div>

        </section>
        </div>
    </main>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('base.novabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\00054957176\PROJETOS\TR\resources\views/cidade/index.blade.php ENDPATH**/ ?>