
<?php $__env->startSection('content'); ?>
<?php 
$processoCount = session()->get('processoCount'); 
$processoCount_corrigir = session()->get('processoCount_corrigir'); 
$processoCount_finalizado = session()->get('processoCount_finalizado'); 
$processoCount_aguardando = session()->get('processoCount_aguardando'); 
$processoCount_tramitada = session()->get('processoCount_tramitada'); 
$processoCount_nao_finalizada = session()->get('processoCount_nao_finalizada'); 
?>
<main id="main" class="main">

  
    <div class="pagetitle">
        <h1>Dashboard</h1>
        <nav>
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Início</a></li>
            <li class="breadcrumb-item active">Painel Gerencial</li>
          </ol>
        </nav>
      </div><!-- End Page Title -->
  

    <div class="row">


        <div class="col-xl-3 col-md-6 col-sm-12">
            <div class="card">
                <div class="card-content">
                    <img class="card-img img-fluid" src="<?php echo e(asset('/images/painel/dre.png')); ?>" width="100px" alt="Card image">
                    <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
                        <div class="overlay-content">
                            <h4 class="card-title mb-50">Cadastro de Entidades </h4>
                            <p class="card-text text-ellipsis">
                                Cadastro e Consulta Entidades.
                            </p>
                        </div>
                        <div class="overlay-status">
                            <a href="<?php echo e(asset('/entidades')); ?>" class="btn btn-primary btn-sm">Clique aqui </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-12">
            <div class="card">
                <div class="card-content">
                    <img class="card-img img-fluid" src="<?php echo e(asset('/images/painel/dre.png')); ?>" width="100px" alt="Card image">
                    <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
                        <div class="overlay-content">
                            <h4 class="card-title mb-50">Cadastro de Entidades Tipo </h4>
                            <p class="card-text text-ellipsis">
                                Cadastro e Consulta Entidades Tipo.
                            </p>
                        </div>
                        <div class="overlay-status">
                            <a href="<?php echo e(asset('/entidades')); ?>" class="btn btn-primary btn-sm">Clique aqui </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-12">
            <div class="card">
                <div class="card-content">
                    <img class="card-img img-fluid" src="<?php echo e(asset('/images/painel/mapabrasil.jpg')); ?>" width="200px" alt="Card image">
                    <div class="card-img-overlay overlay-dark d-flex justify-content-between flex-column">
                        <div class="overlay-content">
                            <h4 class="card-title mb-50">Estados</h4>
                            <p class="card-text text-ellipsis">
                                Consulte os Estado.
                            </p>
                        </div>
                        <div class="overlay-status text-right">
                            <a href="<?php echo e(asset('/estado')); ?>" class="btn btn-primary btn-sm">Clique aqui </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>





<div class="col-xl-3 col-md-6 col-sm-12">
            <div class="card">
                <div class="card-content">
                    <img class="card-img img-fluid" src="<?php echo e(asset('/images/painel/cidades.jpg')); ?>" alt="Card image">
                    <div class="card-img-overlay overlay-dark d-flex justify-content-between flex-column">
                        <div class="overlay-content">
                            <h4 class="card-title mb-50">Cidade</h4>

                            <p class="card-text text-ellipsis">
                                Consulta de Cidades.
                            </p>
                        </div>
                        <div class="overlay-status">
                            <a href="<?php echo e(asset('/cidade')); ?>" class="btn btn-primary btn-sm">Clique aqui </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-12">
            <div class="card">
                <div class="card-content">
                    <img class="card-img img-fluid" src="<?php echo e(asset('/images/painel/escolas.jpg')); ?>" alt="Card image">
                    <div class="card-img-overlay overlay-dark d-flex justify-content-between flex-column">
                        <div class="overlay-content">
                            <h4 class="card-title mb-50">Questões do Fomulário</h4>
                            <p class="card-text text-ellipsis">
                                Cadastro e Consulta de Questões do Fomulário
                            </p>
                        </div>
                        <div class="overlay-status text-right">
                            <a href="<?php echo e(asset('/questoes')); ?>" class="btn btn-primary btn-sm">Clique aqui </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-12">
            <div class="card">
                <div class="card-content">
                    <img class="card-img img-fluid" src="<?php echo e(asset('/images/painel/cating.jpg')); ?>" alt="Card image">
                    <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
                        <div class="overlay-content">
                            <h4 class="card-title mb-50">Categoria dos Ingredientes</h4>
                            <p class="card-text text-ellipsis">
                                Cadastro e Consulta de Categoria Ingredientes.
                            </p>
                        </div>
                        <div class="overlay-status">
                            <a href="<?php echo e(asset('/catingrediente')); ?>" class="btn btn-primary btn-sm">Clique aqui </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-12">
            <div class="card">
                <div class="card-content">
                    <img class="card-img img-fluid" src="<?php echo e(asset('/images/painel/ingredientes.jpg')); ?>" alt="Card image">
                    <div class="card-img-overlay overlay-dark d-flex justify-content-between flex-column">
                        <div class="overlay-content">
                            <h4 class="card-title mb-50">Cadastro de Ingredientes</h4>

                            <p class="card-text text-ellipsis">
                                Cadastro e Consulta de Ingredientes.
                            </p>
                        </div>
                        <div class="overlay-status text-right">
                            <a href="<?php echo e(asset('/insumo')); ?>" class="btn btn-primary btn-sm">Clique aqui </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    

    </div></main>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('base.novabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\00054957176\PROJETOS\TR\resources\views/painel/index.blade.php ENDPATH**/ ?>